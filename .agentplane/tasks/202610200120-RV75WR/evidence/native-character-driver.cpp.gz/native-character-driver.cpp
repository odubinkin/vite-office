#include <cstdint>
#include <cstdio>
#include "unicode/utypes.h"
#include "unicode/uchar.h"
#include "unicode/ucptrie.h"
#include "unicode/uscript.h"
#include "utrie2.h"
#include "uprops.h"
#define INCLUDED_FROM_UCHAR_C
#include "uchar_props_data.h"
#define GET_PROPS(c, result) ((result)=UTRIE2_GET16(&propsTrie, c))
U_CAPI int8_t U_EXPORT2
u_charType(UChar32 c) {
    uint32_t props;
    GET_PROPS(c, props);
    return (int8_t)GET_CATEGORY(props);
}

using sal_uInt32=uint32_t; using sal_Int16=int16_t;
namespace css::i18n::UnicodeType {
constexpr int16_t UNASSIGNED=0;
constexpr int16_t UPPERCASE_LETTER=1;
constexpr int16_t LOWERCASE_LETTER=2;
constexpr int16_t TITLECASE_LETTER=3;
constexpr int16_t MODIFIER_LETTER=4;
constexpr int16_t OTHER_LETTER=5;
constexpr int16_t NON_SPACING_MARK=6;
constexpr int16_t ENCLOSING_MARK=7;
constexpr int16_t COMBINING_SPACING_MARK=8;
constexpr int16_t DECIMAL_DIGIT_NUMBER=9;
constexpr int16_t LETTER_NUMBER=10;
constexpr int16_t OTHER_NUMBER=11;
constexpr int16_t SPACE_SEPARATOR=12;
constexpr int16_t LINE_SEPARATOR=13;
constexpr int16_t PARAGRAPH_SEPARATOR=14;
constexpr int16_t CONTROL=15;
constexpr int16_t FORMAT=16;
constexpr int16_t PRIVATE_USE=17;
constexpr int16_t SURROGATE=18;
constexpr int16_t DASH_PUNCTUATION=19;
constexpr int16_t INITIAL_PUNCTUATION=20;
constexpr int16_t FINAL_PUNCTUATION=21;
constexpr int16_t CONNECTOR_PUNCTUATION=22;
constexpr int16_t OTHER_PUNCTUATION=23;
constexpr int16_t MATH_SYMBOL=24;
constexpr int16_t CURRENCY_SYMBOL=25;
constexpr int16_t MODIFIER_SYMBOL=26;
constexpr int16_t OTHER_SYMBOL=27;
constexpr int16_t START_PUNCTUATION=28;
constexpr int16_t END_PUNCTUATION=29;
constexpr int16_t GENERAL_TYPES_COUNT=30;
}
class unicode { public: static sal_Int16 getUnicodeType(sal_uInt32); static bool isControl(sal_uInt32); static bool isAlpha(sal_uInt32); };
sal_Int16
unicode::getUnicodeType(const sal_uInt32 ch)
{
    static thread_local sal_uInt32 c = 0x00;
    static thread_local sal_Int16 r = 0x00;

    if (ch == c) return r;
    else c = ch;

    switch (u_charType(ch))
    {
        case U_UNASSIGNED:
            r = css::i18n::UnicodeType::UNASSIGNED;
            break;
        case U_UPPERCASE_LETTER:
            r = css::i18n::UnicodeType::UPPERCASE_LETTER;
            break;
        case U_LOWERCASE_LETTER:
            r = css::i18n::UnicodeType::LOWERCASE_LETTER;
            break;
        case U_TITLECASE_LETTER:
            r = css::i18n::UnicodeType::TITLECASE_LETTER;
            break;
        case U_MODIFIER_LETTER:
            r = css::i18n::UnicodeType::MODIFIER_LETTER;
            break;
        case U_OTHER_LETTER:
            r = css::i18n::UnicodeType::OTHER_LETTER;
            break;
        case U_NON_SPACING_MARK:
            r = css::i18n::UnicodeType::NON_SPACING_MARK;
            break;
        case U_ENCLOSING_MARK:
            r = css::i18n::UnicodeType::ENCLOSING_MARK;
            break;
        case U_COMBINING_SPACING_MARK:
            r = css::i18n::UnicodeType::COMBINING_SPACING_MARK;
            break;
        case U_DECIMAL_DIGIT_NUMBER:
            r = css::i18n::UnicodeType::DECIMAL_DIGIT_NUMBER;
            break;
        case U_LETTER_NUMBER:
            r = css::i18n::UnicodeType::LETTER_NUMBER;
            break;
        case U_OTHER_NUMBER:
            r = css::i18n::UnicodeType::OTHER_NUMBER;
            break;
        case U_SPACE_SEPARATOR:
            r = css::i18n::UnicodeType::SPACE_SEPARATOR;
            break;
        case U_LINE_SEPARATOR:
            r = css::i18n::UnicodeType::LINE_SEPARATOR;
            break;
        case U_PARAGRAPH_SEPARATOR:
            r = css::i18n::UnicodeType::PARAGRAPH_SEPARATOR;
            break;
        case U_CONTROL_CHAR:
            r = css::i18n::UnicodeType::CONTROL;
            break;
        case U_FORMAT_CHAR:
            r = css::i18n::UnicodeType::FORMAT;
            break;
        case U_PRIVATE_USE_CHAR:
            r = css::i18n::UnicodeType::PRIVATE_USE;
            break;
        case U_SURROGATE:
            r = css::i18n::UnicodeType::SURROGATE;
            break;
        case U_DASH_PUNCTUATION:
            r = css::i18n::UnicodeType::DASH_PUNCTUATION;
            break;
        case U_INITIAL_PUNCTUATION:
            r = css::i18n::UnicodeType::INITIAL_PUNCTUATION;
            break;
        case U_FINAL_PUNCTUATION:
            r = css::i18n::UnicodeType::FINAL_PUNCTUATION;
            break;
        case U_CONNECTOR_PUNCTUATION:
            r = css::i18n::UnicodeType::CONNECTOR_PUNCTUATION;
            break;
        case U_OTHER_PUNCTUATION:
            r = css::i18n::UnicodeType::OTHER_PUNCTUATION;
            break;
        case U_MATH_SYMBOL:
            r = css::i18n::UnicodeType::MATH_SYMBOL;
            break;
        case U_CURRENCY_SYMBOL:
            r = css::i18n::UnicodeType::CURRENCY_SYMBOL;
            break;
        case U_MODIFIER_SYMBOL:
            r = css::i18n::UnicodeType::MODIFIER_SYMBOL;
            break;
        case U_OTHER_SYMBOL:
            r = css::i18n::UnicodeType::OTHER_SYMBOL;
            break;
        case U_START_PUNCTUATION:
            r = css::i18n::UnicodeType::START_PUNCTUATION;
            break;
        case U_END_PUNCTUATION:
            r = css::i18n::UnicodeType::END_PUNCTUATION;
            break;
    }

    return r;
}
static constexpr auto bit(sal_Int16 name) { return 1U << name; }

bool unicode::isControl(const sal_uInt32 ch)
{
    const auto CONTROLMASK = bit(css::i18n::UnicodeType::CONTROL) |
                             bit(css::i18n::UnicodeType::FORMAT) |
                             bit(css::i18n::UnicodeType::LINE_SEPARATOR) |
                             bit(css::i18n::UnicodeType::PARAGRAPH_SEPARATOR);
    return (bit(getUnicodeType(ch)) & CONTROLMASK) != 0;
}

bool unicode::isAlpha(const sal_uInt32 ch)
{
    const auto ALPHAMASK = bit(css::i18n::UnicodeType::UPPERCASE_LETTER) |
                           bit(css::i18n::UnicodeType::LOWERCASE_LETTER) |
                           bit(css::i18n::UnicodeType::TITLECASE_LETTER) |
                           bit(css::i18n::UnicodeType::MODIFIER_LETTER) |
                           bit(css::i18n::UnicodeType::OTHER_LETTER);
    return (bit(getUnicodeType(ch)) & ALPHAMASK) != 0;
}

int main() {
 for(uint32_t c=0;c<0x110000;c++) {
  unsigned char data[4]={static_cast<unsigned char>(u_charType(c)),static_cast<unsigned char>(unicode::getUnicodeType(c)),static_cast<unsigned char>(unicode::isAlpha(c)),static_cast<unsigned char>(unicode::isControl(c))};
  if(fwrite(data,1,4,stdout)!=4)return 1;
 }
 return 0;
}
